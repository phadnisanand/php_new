<?php

namespace Drupal\panelizer\Exception;

/**
 * Exception class for PanelizerExceptions.
 */
class PanelizerException extends \RuntimeException {
}
